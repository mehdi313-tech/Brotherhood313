BROTHERHOOD 313 website update — Contact section

This version adds a Contact Us section and WhatsApp links using the number provided, with India's country code (91): 918803982981.

Please test the WhatsApp links before publishing. If the number is not a WhatsApp account or was entered incorrectly, edit the WHATSAPP_NUMBER constant in index.html.

Instagram is not configured yet; add your real Instagram profile link when ready.

To update GitHub Pages:
1. Open your brotherhood313 repository.
2. Open index.html and replace its contents with this updated index.html, OR delete the old file and upload this one.
3. Commit changes.
4. Wait a few minutes and refresh the published site.

Sample prices and mock product visuals should be updated to match actual products before taking orders.
